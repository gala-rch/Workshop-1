#pragma once

#include "../../src/Image.h"
#include "../../src/Load.h"
#include "../../src/Save.h"
#include "../../src/Size.h"
#include "../../src/SizeU.h"